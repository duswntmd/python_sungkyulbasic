bread=["스콘","크로아상","소금빵"]
drink=["coffee","juice","milk"]
dessert=["cake","choco"]
for b in bread:
    for d in drink:
        for k in dessert:
            print(b,"+",d, "+", k)
